from django.apps import AppConfig

class petpickerConfig(AppConfig):
    name = 'petpicker'
